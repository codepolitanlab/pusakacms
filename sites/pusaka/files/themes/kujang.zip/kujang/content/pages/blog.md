{: title :} Blog
{: slug :} blog
{: content :} Blog Content
