<div id="footer-bottom">
	<div class="container clearfix">
		<div class="col-md-6 footer-nav">
			<a href="http://www.nyankod.com" target="_blank">Nyankod</a> &bull;
			<a href="http://www.codepolitan.com" target="_blank">Codepolitan</a> &bull;
			<a href="http://magz.nyankod.com" target="_blank">NyankodMagz</a>
		</div>
		<div class="col-md-6" style="text-align:right">
			Copyright ©2014 <a href="http://www.nyankod.com" target="_blank">Nyankod</a>. All rights reserved. 
			Powered by <a href="http://pusakacms.nyankod.com" target="_blank">PusakaCMS</a>
		</div>
	</div>	<!-- .container -->
</div>

<script src="<?php echo get_theme_url() ?>/assets/js/jquery.min.js"></script>
<script src="<?php echo get_theme_url() ?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo get_theme_url() ?>/assets/js/script.js"></script>