<nav class="navbar navbar-default" role="navigation">
	<div class="container">		
		<div class="row">
			<div class="col-md-7">
				<div class="navbar-header">
					<h1><a href="<?php echo site_url(); ?>">{{ site_name }}</a></h1>
				</div>
			</div>
		</div>
	</div>
</nav>