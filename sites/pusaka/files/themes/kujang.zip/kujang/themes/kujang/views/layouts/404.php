<!DOCTYPE html>
<html lang="en">
<head>
	<?php get_partial('metadata'); ?>
</head>
<body class="notfound-wrapper">

	<div class="notfound-inner text-center">

		<div class="container">		
			
			<h1>Error 404</h1>
					
			<div class="text-wrapper">Page not found, guys..</div>

			<a href="<?php echo site_url(); ?>" class="btn btn-primary btn-lg"><span class="fa fa-long-arrow-left"></span> Back to Jakarta</a>
				
		</div>

	</div>
	
</body>
</html>