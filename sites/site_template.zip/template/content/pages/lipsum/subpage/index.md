{: title :} Subpage
{: slug :} subpage
{: parent :} lipsum
{: content :} Sample Sub Page
